var config = {
    map: {
        '*': {
            pixtronowlcarousel: 'Hiddentechies_Pixtron/js/owl.carousel',
        }
    }
};